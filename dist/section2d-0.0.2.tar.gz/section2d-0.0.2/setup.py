from setuptools import setup
from os import path

DIR = path.dirname(path.abspath(__file__))

with open(path.join(DIR, 'README.md')) as f:
    README = f.read()

setup(
    name='section2d',
    packages=['section2d'],
    description="...",
    long_description=README,
    long_description_content_type='text/markdown',
    install_requires=['torch', 'torchvision'],
    version='0.0.2',
    url='https://github.com/shun321-star/section2d',
    author='shun.321',
    author_email='shun.321@sjtu.edu.cn',
    license = 'MIT',
    keywords=['None',],
    tests_require=[
        'pytest',
        'pytest-cov',
        'pytest-sugar'
    ],
    package_data={
        # include json and pkl files
        '': ['*.json', 'models/*.pkl', 'models/*.json'],
    },
    include_package_data=True,
    python_requires='>=3.8'
)