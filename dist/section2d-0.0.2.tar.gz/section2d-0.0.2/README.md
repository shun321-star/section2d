# 2Dsection

```
This is a package for paper .... You can get more details and updates from
https://github.com/shun321-star/2Dsection.
```



Contact: shun.321@sjtu.edu.cn

